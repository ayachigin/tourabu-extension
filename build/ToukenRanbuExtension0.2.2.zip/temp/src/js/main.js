var TourabuEx = TourabuEx || {};

new TourabuEx.Dispatcher();
